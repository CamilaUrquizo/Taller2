public class Venta implements Comparable<Venta>{
    private int idVenta;
    private String nombreProducto;
    private int cantidad;
    private double precio;

    public Venta(int idVenta, String nombreProducto, int cantidad, double precio) {
        this.idVenta = idVenta;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.precio = precio;
    }

    public int getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public int compareTo(Venta nuevaVenta){
        return Integer.compare(this.idVenta, nuevaVenta.getIdVenta());
    }

    @Override
    public String toString() {
        return  "ID: " + idVenta +
                "; Nombre del Producto: " + nombreProducto +
                "; Cantidad: " + cantidad +
                "; Precio: " + precio;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Venta venta = (Venta) obj;
        return idVenta == venta.idVenta;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(idVenta);
    }
}
