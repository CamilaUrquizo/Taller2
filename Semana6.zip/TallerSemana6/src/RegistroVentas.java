import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RegistroVentas {
    private ArrayList<Venta> ventas;

    public RegistroVentas() {
        ventas = new ArrayList<Venta>();
    }

    public void registrarVenta(Venta venta){
        ventas.add(venta);
        Collections.sort(ventas);
    }

    public Venta buscarPorId(int id) {
        return buscarPorIdRec(id, 0, ventas.size() - 1);
    }

    private Venta buscarPorIdRec(int id, int inferior, int superior) {
        if (inferior > superior) return null;

        int medio = (inferior + superior) / 2;
        Venta v = ventas.get(medio);

        if (v.getIdVenta() == id) {
            return v;
        }

        if (id < v.getIdVenta()) {
            return buscarPorIdRec(id, inferior, medio - 1);
        } else {
            return buscarPorIdRec(id, medio + 1, superior);
        }
    }

    public Venta buscarPorNombre(String nombre) {
        ArrayList<Venta> copia = new ArrayList<>(ventas);
        copia.sort((a, b) -> a.getNombreProducto().compareToIgnoreCase(b.getNombreProducto()));

        return buscarPorNombreRec(nombre, copia, 0, copia.size() - 1);
    }

    private Venta buscarPorNombreRec(String nombre, ArrayList<Venta> lista, int inicio, int fin) {
        if (inicio > fin) return null;

        int medio = (inicio + fin) / 2;
        Venta v = lista.get(medio);

        int cmp = nombre.compareToIgnoreCase(v.getNombreProducto());

        if (cmp == 0) {
            return v;
        }

        if (cmp < 0) {
            return buscarPorNombreRec(nombre, lista, inicio, medio - 1);
        } else {
            return buscarPorNombreRec(nombre, lista, medio + 1, fin);
        }
    }

    public List<Venta> registro (){
        return ventas;
    }
}

