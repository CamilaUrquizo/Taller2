import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Ventana {
    private JTabbedPane tabbedPane1;
    private JPanel principal;
    private JButton btnRegistrar;
    private JTextField txtProducto;
    private JTextField txtId;
    private JTextField txtCantidad;
    private JTextField txtPrecio;
    private JButton MOSTRARREGISTROButton;
    private JList<Venta> lstRegistro;
    private JButton btnBuscar;
    private JTextField txtBId;
    private JTextField txtBNombre;
    private JButton btnEditar;
    private JTextField txtNuevoPrecio;
    RegistroVentas ventas = new RegistroVentas();
    int indice;

    public Ventana() {
        btnRegistrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idProducto = Integer.parseInt(txtId.getText());
                String nombreProducto = txtProducto.getText();
                int cantidad = Integer.parseInt(txtCantidad.getText());
                double precio = Double.parseDouble(txtPrecio.getText());
                ventas.registrarVenta(new Venta(idProducto, nombreProducto, cantidad, precio));

                JOptionPane.showMessageDialog(null, "La venta se ha registrado exitosamente");

                txtId.setText("");
                txtCantidad.setText("");
                txtPrecio.setText("");
                txtProducto.setText("");
            }
        });
        MOSTRARREGISTROButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel<Venta> dlm = new DefaultListModel<>();
                for (Venta v : ventas.registro()) {
                    dlm.addElement(v);
                }
                lstRegistro.setModel(dlm);
            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                DefaultListModel<Venta> dlm = new DefaultListModel<>();
                List<Venta> lista = ventas.registro();
                for (Venta v : lista) {
                    dlm.addElement(v);
                }
                lstRegistro.setModel(dlm);

                String idTexto = txtBId.getText().trim();
                String nombreTexto = txtBNombre.getText().trim();

                Venta encontradaPorId = null;
                Venta encontradaPorNombre = null;


                if (!idTexto.isEmpty()) {
                    try {
                        int id = Integer.parseInt(idTexto);
                        encontradaPorId = ventas.buscarPorId(id);

                        if (encontradaPorId == null) {
                            JOptionPane.showMessageDialog(null, "No existe venta con ese ID.");
                            return;
                        }

                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "El ID debe ser un número válido.");
                        return;
                    }
                }


                if (!nombreTexto.isEmpty()) {
                    encontradaPorNombre = ventas.buscarPorNombre(nombreTexto);

                    if (encontradaPorNombre == null) {
                        JOptionPane.showMessageDialog(null, "No existe venta con ese nombre de producto.");
                        return;
                    }
                }


                if (idTexto.isEmpty() && nombreTexto.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Ingrese un ID o un Nombre para buscar.");
                    return;
                }


                if (encontradaPorId != null && encontradaPorNombre != null) {
                    if (!encontradaPorId.equals(encontradaPorNombre)) {
                        JOptionPane.showMessageDialog(null,
                                "El ID y el Nombre no corresponden a la misma venta.");
                        return;
                    }
                }


                Venta encontrada = (encontradaPorId != null) ? encontradaPorId : encontradaPorNombre;


                int index = dlm.indexOf(encontrada);

                if (index != -1) {
                    lstRegistro.setSelectedIndex(index);
                    lstRegistro.ensureIndexIsVisible(index);
                }
            }
        });
        lstRegistro.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (lstRegistro.getSelectedIndex() != -1){
                    indice = lstRegistro.getSelectedIndex();
                    Venta vn = ventas.registro().get(indice);
                    txtId.setText(""+vn.getIdVenta());
                    txtProducto.setText(vn.getNombreProducto());
                    txtCantidad.setText(""+vn.getCantidad());
                    txtPrecio.setText(""+vn.getPrecio());

                }

            }
        });

        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Venta seleccionada = lstRegistro.getSelectedValue();
                if (seleccionada == null) {
                    JOptionPane.showMessageDialog(null, "Debes seleccionar un producto del registro.");
                    return;
                }

                if (txtNuevoPrecio.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Ingresa un nuevo precio.");
                    return;
                }

                try {
                    double nuevoPrecio = Double.parseDouble(txtNuevoPrecio.getText());

                    seleccionada.setPrecio(nuevoPrecio);

                    JOptionPane.showMessageDialog(null, "Producto actualizado exitosamente.");

                    lstRegistro.repaint();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "El precio debe ser un número válido.");
                }
            }
        });
    }
        public static void main (String[]args){
            JFrame frame = new JFrame("Ventana");
            frame.setContentPane(new Ventana().principal);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setVisible(true);
        }
    }

